<?php
//Inicio da classe estacionamento
class Estacionamento 
{
	//Atributos da classe
	private $codigoDoEstacionamento;
	private $nome;
	private $endereco;
	private $coberto;
	private $horarios;
	private $valores;
	private $imagem;
	private $servicosOferecidos;

	//Construtor da classe
	function __construct($nome,$endereco,$coberto,$servicosOferecidos,$horarios,$valores,$imagem)
	{
		$this->nome = $nome;
		$this->endereco = $endereco;
		$this->coberto = $coberto;
		$this->servicosOferecidos = $servicosOferecidos;
		$this->horarios = $horarios;
		$this->valores = $valores;
		$this->imagem = $imagem;
	}

	//Metodos de acesso
	public function getCodigoDoEstacionamento(){return $this->codigoDoEstacionamento;}
	public function getNome(){return $this->nome;}
	public function getEndereco(){return $this->endereco;}
	public function getCoberto(){return $this->coberto;}
	public function getHorarios(){return $this->horarios;}
	public function getValores(){return $this->valores;}
	public function getImagem(){return $this->imagem;}
	public function getServicosOferecidos(){return $this->servicosOferecidos;}
}