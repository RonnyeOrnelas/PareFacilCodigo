<?php
//Inicio da classe BancoDeDados
class BancoDeDados
{
    //Variavel que guarda a conexao PDO.
    protected static $db;
    //Construtor privado para garantir que seja istanciadoo somente uma vez
    private function __construct()
    {
        //atributos para conexao ao banco de dados.
        $hospedeiro = "localhost";
        $banco = "PareFacil";
        $usuario = "root";
        $senha = "ro078squ";
        $driver = "mysql";
        // Informações sobre o sistema:
       // $sistema_titulo = "Nome do Sistema";
        //$sistema_email = "alguem@gmail.com";
        try
        {          
            self::$db = new PDO("$driver:host=$hospedeiro; dbname=$banco", $usuario, $senha);
            //Garante que o PDO lance excecoes durante erros.
            self::$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //Garante que os dados sejam armazenados com codificacao UFT-8.
            self::$db->exec('SET NAMES utf8');
        }
        catch (PDOException $e)
        {
            // Envia um e-mail para o e-mail oficial do sistema, em caso de erro de conexão.
            // mail($sistema_email, "PDOException em $sistema_titulo", $e->getMessage());
            //Então não carrega nada mais da página.
            die("Connection Error: " . $e->getMessage());
        }
    }
    //Metodo estatico - acessivel sem instanciacao.
    public static function conexao()
    {
        //Garante uma unica instancia. Se nao existe uma conexao, criamos uma nova.
        if (!self::$db)
        {
            new BancoDeDados();
        }
        //Retorna a conexao.
        return self::$db;
    }
}