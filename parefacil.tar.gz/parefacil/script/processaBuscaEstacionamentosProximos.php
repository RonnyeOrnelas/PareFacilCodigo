<?php
//Forcando verificacao de erros na pagina.
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);

require_once('conexao.php');
//Recuperando instancia do banco de dados
$db = BancoDeDados::conexao();

//Recuperando Bairro enviado por get via json na funcao recuperaEnderecoGeolocalizado no arquivo funcoes.js
$latitude = $_GET["latitude"];
$longitude = $_GET["longitude"];

//Buscando latitude e longitude de pontos proximos pelo bairro
//$query = "SELECT T2.cod_estacionamento,T1.latitude,T1.longitude FROM ENDERECO T1
//INNER JOIN ESTACIONAMENTO T2 ON T1.cod_endereco = T2.cod_endereco";

//Buscando estacionamentos em um raio de 1km
$query = "SELECT T2.cod_estacionamento,T1.latitude,T1.longitude,
	    (6371 * acos(
	     cos( radians($latitude))
	     * cos( radians( latitude ))
	     * cos( radians( longitude ) - radians($longitude))
	     + sin( radians( $latitude ))
	     * sin( radians( latitude ))
	     )
	    ) AS distancia
	    FROM ENDERECO T1
	    INNER JOIN ESTACIONAMENTO T2 ON T1.cod_endereco = T2.cod_endereco
	    HAVING distancia < 1
	    ORDER BY distancia ASC";

//Executando a query
$statement = $db->prepare($query);
$statement->execute();
$dados = array();
while($array = $statement->fetch(\PDO::FETCH_ASSOC))
{
	$estacionamentos[] = $array["cod_estacionamento"];
	$dados[$array["cod_estacionamento"]] = $array;
}

$queryEstacionamentoMaisEmConta = "SELECT 
									    cod_estacionamento AS mais_em_conta
									FROM
									    VALOR
									WHERE
									    cod_estacionamento IN (".implode(',', $estacionamentos).")
									        AND cod_tempo = 1
									ORDER BY preco
									LIMIT 1";
//Executando a query
$statement = $db->prepare($queryEstacionamentoMaisEmConta);
$statement->execute();
$array = $statement->fetch(\PDO::FETCH_ASSOC);

$dados[$array["mais_em_conta"]]['mais_barato'] = true;

$dia = date('N');
$hora = date('G');
$minuto = date('i');
$segunda = date('s');

$queryHorarioEstacionamentos = "SELECT 
								    cod_estacionamento AS aberto
								FROM
								    HORARIO
								WHERE
								    cod_estacionamento IN (".implode(',', $estacionamentos).")
								        AND cod_dia = ".$dia."
								        AND hora_inico <= '".$hora.":".$minuto.":".$segunda."'
								        AND hora_fim >= '".$hora.":".$minuto.":".$segunda."'";
//Executando a query
$statement = $db->prepare($queryHorarioEstacionamentos);
$statement->execute();
while($array = $statement->fetch(\PDO::FETCH_ASSOC))
{
	$dados[$array["aberto"]]['aberto'] = true;
}
//Retornado os dados de volta para a requisicao json
echo json_encode($dados);