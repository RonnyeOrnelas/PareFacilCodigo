<?php
	//Inicio da classe horario funcionamento
	class HorarioFuncionamento 
	{
		//Atributos da classe
		private $dia;
		private $horarioInicio;
		private $horarioFim;
		
		//Construtor da classe
		function __construct($dia,$horarioInicio,$horarioFim)
		{
			$this->dia = $dia;
			$this->horarioInicio = $horarioInicio;
			$this->horarioFim = $horarioFim;
		}

		//Metodos de acesso
		public function getDia(){return $this->dia;}
		public function getHorarioInicio(){return $this->horarioInicio;}
		public function getHorarioFim(){return $this->horarioFim;}
	}