<?php
	//Inicio da classe servico adicional
	class ServicoAdicional 
	{
		//Atributos da classe
		private $codigoDoServico;
		private $descricao;
		
		//Construtor da classe
		function __construct($descricao)
		{
			$this->descricao = $descricao;
		}

		//Metodos de acesso
		public function getCodigoDoServico(){return $this->codigoDoServico;}
		public function getDescricao(){return $this->descricao;}
	}