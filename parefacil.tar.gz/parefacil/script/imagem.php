<?php
	//Inicio da classe imagem
	class Imagem 
	{
		//Atributos da classe
		private $codigoDaImagem;
		private $caminho;
		
		//Construtor da classe
		function __construct($caminho)
		{
			$this->caminho = $caminho;
		}

		//Metodos de acesso
		public function getCodigoDaImagem(){return $this->codigoDaImagem;}
		public function getCaminho(){return $this->caminho;}
	}