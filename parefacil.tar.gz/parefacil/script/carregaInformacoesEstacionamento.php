<?php
//Forcando verificacao de erros na pagina.
ini_set('display_errors',1);
ini_set('display_startup_erros',1);
error_reporting(E_ALL);

//Requisicoes Necessarias
require_once('conexao.php');
require_once('estacionamento.php');
require_once('endereco.php');
require_once('servicoAdicional.php');
require_once('horarioFuncionamento.php');
require_once('valor.php');
require_once('imagem.php');

//Recuperando instancia do banco de dados
$db = BancoDeDados::conexao();

//Valor passado ao selecionar o estacionamento no mapa
$cod_estacionamento = $_GET["cod_estacionamento"];

//Selecionando o estacionamento
$queryEstacionamento = "SELECT 
						    T1.nome,
						    T1.coberto,
						    T2.logradouro,
						    T2.numero,
						    T2.bairro,
						    T2.cidade,
						    T2.estado,
						    T2.cep,
							T3.caminho
						FROM
						    ESTACIONAMENTO T1
						        INNER JOIN
						    ENDERECO T2 ON T1.cod_endereco = T2.cod_endereco
							INNER JOIN IMAGEM T3 ON T1.cod_imagem = T3.cod_imagem
						WHERE
						    T1.cod_estacionamento = $cod_estacionamento";
//Executando a query
$statement = $db->prepare($queryEstacionamento);
$statement->execute();

while($array = $statement->fetch(\PDO::FETCH_ASSOC))
{
	//Nova instancia de Imagem
	$imagem = new Imagem($array["caminho"]); 

	//Nova instancia de Endereco
	$endereco = new Endereco($array["logradouro"],$array["numero"],$array["bairro"],$array["cidade"],$array["estado"],$array["cep"]);

	//Selecionando os servicos oferecidos pelo estacionamento
	$queryServicosOferecidos = "SELECT 
								    T2.descricao
								FROM
								    SERVICO T1
								        INNER JOIN
								    TIPO_SERVICO T2 ON T1.cod_tipo_servico = T2.cod_tipo_servico
								WHERE
								    T1.cod_estacionamento = $cod_estacionamento";
	//Executando a query							    
	$statementServicosOferecidos = $db->prepare($queryServicosOferecidos);
	$statementServicosOferecidos->execute();

	while($arrayServicosOferecidos = $statementServicosOferecidos->fetch(\PDO::FETCH_ASSOC))
	{
		//Nova Instancia de ServicosOferecidos
		$servicosOferecidos[] = $servico = new servicoAdicional($arrayServicosOferecidos["descricao"]);
	}

	//Selecionando os Servicos Oferecidos
	$queryHorarioDeFuncionamento = "SELECT 
									    T2.descricao, T1.hora_inico, T1.hora_fim
									FROM
									    HORARIO T1
									        INNER JOIN
									    DIA T2 ON T1.cod_dia = T2.cod_dia
									WHERE
									    T1.cod_estacionamento = $cod_estacionamento";
	//Executando a query									    
	$statementHorarioDeFuncionamento = $db->prepare($queryHorarioDeFuncionamento);
	$statementHorarioDeFuncionamento->execute();

	while($arrayHorarioDeFuncionamento = $statementHorarioDeFuncionamento->fetch(\PDO::FETCH_ASSOC))
	{
		//Nova Instancia de HorarioFuncionamento
		$horariosDeFuncionamento[] = new HorarioFuncionamento($arrayHorarioDeFuncionamento["descricao"],$arrayHorarioDeFuncionamento["hora_inico"],$arrayHorarioDeFuncionamento["hora_fim"]);
	}

	//Selecionando os valores cobrados pelo estacionamento
	$queryValoresCobrados = "SELECT 
					    T2.tempo, T1.preco
					FROM
					    VALOR T1
					        INNER JOIN
					    TEMPO T2 ON T1.cod_tempo = T2.cod_tempo
					WHERE
					    T1.cod_estacionamento = $cod_estacionamento";
	//Executando a query					    
	$statementValoresCobrados = $db->prepare($queryValoresCobrados);
	$statementValoresCobrados->execute();

	while($arrayValoresCobrados = $statementValoresCobrados->fetch(\PDO::FETCH_ASSOC))
	{
		//Nova instancia de Valor
		$valoresCobrados[] = new Valor($arrayValoresCobrados["tempo"],$arrayValoresCobrados["preco"]);
	}
	//Nova instancia de Estacionamento
	$estacionamento = new Estacionamento($array["nome"],$endereco,$array["coberto"],$servicosOferecidos,$horariosDeFuncionamento,$valoresCobrados,$imagem);								    	
}

//Preenchendo conteudo da informacao do estacionamento
$conteudo = '<h3>'.$estacionamento->getNome().'<img id="imgRota" class="img-rounded" src="img/rota.png" onclick="tracarRota()"/></h3>';
$conteudo .= '<div id="conteudoInformacaoEstacionamento" class="row">';
$conteudo .= '<div class="col-sm-4" style="background-color:lavender;">';
$conteudo .= '<strong>Endereço:</strong><br/>'. $estacionamento->getEndereco()->getLogradouro().','.$estacionamento->getEndereco()->getNumero().','.$estacionamento->getEndereco()->getBairro().','.$estacionamento->getEndereco()->getCidade().' - '.$estacionamento->getEndereco()->getEstado().' - '.$estacionamento->getEndereco()->getCep();
$conteudo .= '<div id="conteudoInformacaoEstacionamento2" class="row">';
$conteudo .= '<div class="col-sm-6" style="background-color:lavender;">';
$conteudo .= '<strong>Coberto:</strong><br/>';

if($estacionamento->getCoberto() == 0)
{
	$conteudo .= "Não";
}
elseif($estacionamento->getCoberto() == 1)
{
	$conteudo .= "Sim";
}
else
{
	$conteudo .= "Semi";
}

$conteudo .= '</div>';
$conteudo .= '<div class="col-sm-6" style="background-color:lavender;">';
$conteudo .= '<strong>Serviços Extras:</strong><br/>';
$conteudo .= '<ul>';
foreach ($estacionamento->getServicosOferecidos() as $value) 
{
	$conteudo .= '<li>';
	$conteudo .= $value->getDescricao();
	$conteudo .= '</li>';	
}
$conteudo .= '</ul>';
$conteudo .= '</div>';
$conteudo .= '</div>';
$conteudo .= '<div id="conteudoInformacaoEstacionamento3" class="row">';
$conteudo .= '<div class="col-sm-12" style="background-color:lavender;">';
$conteudo .= '<strong>Horário de Funcionamento:</strong><br/>';
$conteudo .= '<table class="table table-striped">';
$conteudo .= '<thead>';
$conteudo .= '<tr>';
$conteudo .= '<th>Dia</th>';
$conteudo .= '<th>Horário</th>';									     
$conteudo .= '</tr>';
$conteudo .= '</thead>';
$conteudo .= '<tbody>';
foreach ($estacionamento->getHorarios() as $value) 
{
	$conteudo .= '<tr>';
    $conteudo .= '<td>'.$value->getDia().'</td>';
    $conteudo .= '<td>De '.$value->getHorarioInicio().' as '.$value->getHorarioFim().'</td>';			        
  	$conteudo .= '</tr>';
}
$conteudo .= '</tbody>';
$conteudo .= '</table>';
$conteudo .= '</div>';
$conteudo .= '</div>';
$conteudo .= '</div>';
$conteudo .= '<div class="col-sm-2">';
$conteudo .= '<table class="table table-striped">';
$conteudo .= '<thead>';
$conteudo .= '<tr>';
$conteudo .= '<th>Tempo</th>';
$conteudo .= '<th>Preco</th>';
$conteudo .= '</tr>';
$conteudo .= '</thead>';
$conteudo .= '<tbody>';

foreach ($estacionamento->getValores() as $value) 
{
	$conteudo .= '<tr>';
    $conteudo .= '<td>'.$value->getTempo().'</td>';
    $conteudo .= '<td>R$ '.$value->getPreco().'</td>';
  	$conteudo .= '</tr>';  	
}
$conteudo .= '</tbody>';
$conteudo .= '</table>';
$conteudo .= '</div>';

$conteudo .= '<div class="col-sm-6">';
$conteudo .= '<img class="img-responsive" src="img/ImagensEstacionamentos/'.$estacionamento->getImagem()->getCaminho().'"/>';
$conteudo .= '</div>';
$conteudo .= '</div>';  							
$conteudo .= '</div>';
$conteudo .= '</div>';					

//Retornado os dados de volta para a requisicao
echo $conteudo;