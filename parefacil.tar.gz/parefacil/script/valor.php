<?php
	//Inicio da classe valor
	class Valor 
	{
		//Atributos da classe
		private $tempo;
		private $preco;		
		
		//Construtor da classe
		function __construct($tempo,$preco)
		{
			$this->tempo = $tempo;
			$this->preco = $preco;
		}

		//Metodos de acesso
		public function getTempo(){return $this->tempo;}
		public function getPreco(){return $this->preco;}		
	}