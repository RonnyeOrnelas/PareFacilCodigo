//Abre o modal de opcao de busca ao iniciar a pagina ------------------------------------------------------
$(document).ready(function() {
    $('#opcaoBusca').modal('show');  
});
//Fecha o modal de opcao de busca ao selecionar uma opcao
function fechaOpcaoBusca()
{
    $('#opcaoBusca').modal('hide');
}
//Abre a Busca por endereco
function abreBuscaPorEndereco()
{
    $('#buscaPorEndereco').modal('show');
    iniciaAutocompletarBusca();
}
//Fecha a Busca por endereco
function fechaBuscaPorEndereco()
{
    $('#txtEndereco').val("");
    $('#buscaPorEndereco').modal('hide');  
}
//Fecha as informacoes detalhadas do estacionamento
function escondeInformacoesEstacionamento()
{
    $('#informacaoEstacionamento').hide();    
}
//Fecha informacao de detalhamento de rota
function escondeInformacaoBusca()
{
    $('#trajeto-texto').hide();
}
//---------------------------------------------------------------------------------------------------------
//Variaveis utilizadas para o Google Maps
var map; //Variavel para carregar o mapa
var directionsDisplay;
var directionsService;
var strictBounds; //variavel para definir limites do mapa
//Para usar ao rquisitar uma rota
var inicio;//variavel com infomacao de lat e long do local geolocalizado ou encontrado pela busca
var fim;//variavel com informacao de lat e long do estacionamento selecionado

//Inicializando Google Maps -------------------------------------------------------------------------------
function initMap()
{
    directionsDisplay = new google.maps.DirectionsRenderer();
    directionsService = new google.maps.DirectionsService();
    //Limitando o nivel minimo de aproximacao
    var minZoomLevel = 12;
    //Inicializando na cidade de Contagem -MG
    var inicial = {lat: -19.8919877, lng: -44.0808763};
    map = new google.maps.Map(document.getElementById('mapa'),{
    zoom: minZoomLevel,
    center: inicial,
    });
    
    //Definindo Limite para regiao onde se localiza a cidade de Contagem MG
    strictBounds = new google.maps.LatLngBounds(
        new google.maps.LatLng(-19.8919877,-44.1525225), 
        new google.maps.LatLng(-19.9161508,-44.0808763)
    );
    //Ao arrastar o mapa para fora dos limites ele retorna para dentro dos limites
    google.maps.event.addListener(map, 'dragend', function() {
        if (strictBounds.contains(map.getCenter())) return;
         
        var c = map.getCenter(),
                x = c.lng(),
                y = c.lat(),
                maxX = -44.0808763,
                maxY = -19.8919877,
                minX = -44.1525225,
                minY = -19.9161508;
        if (x < minX) x = minX;
        if (x > maxX) x = maxX;
        if (y < minY) y = minY;
        if (y > maxY) y = maxY;
        map.setCenter(new google.maps.LatLng(y, x));
    });
    //Limitando a aproximacao atravez no limite de aproximacao minimo definido
    google.maps.event.addListener(map, 'zoom_changed', function() {
        if (map.getZoom() < minZoomLevel) map.setZoom(minZoomLevel);
    });
    //Legenda do Mapa
    map.controls[google.maps.ControlPosition.RIGHT_TOP].push
    (document.getElementById('legenda'));
    $('#legenda').hide();
    //Carregando div para informacoes de rota e escondendo
    map.controls[google.maps.ControlPosition.LEFT_TOP].push
    (document.getElementById('trajeto-texto'));
    $('#trajeto-texto').hide();
}
//---------------------------------------------------------------------------------------------------------
var infowindow;
var pos;
//Ativando Geolocalizacao ---------------------------------------------------------------------------------
function iniciaGeolocalizacao()
{ 
    if (navigator.geolocation) 
    {       
        navigator.geolocation.getCurrentPosition(function(position) 
        {
            pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
           
            infowindow = new google.maps.InfoWindow();

            var marker = new google.maps.Marker({
                position: pos,
                map: map
            });

            infowindow.setContent('<div id="resultado">'+pos.lat+' , '+pos.lng+'</div>');
            inicio = pos.lat+' , '+pos.lng;

            google.maps.event.addListener(marker, 'click', function() {
                infowindow.open(map, marker);
            });

            map.setCenter(pos);
            //manda latitude e longitude para recuperar endereco encontrado
            recuperaEnderecoGeolocalizado(pos.lat,pos.lng);
        }, function() {
                handleLocationError(true, infowindow, map.getCenter());
            });
    } else 
    {
        handleLocationError(false, infowindow, map.getCenter());
    }
}
function handleLocationError(browserHasGeolocation, infowindow, pos) 
{
    infowindow.setPosition(pos);
    infowindow.setContent(browserHasGeolocation ?
    'Error: The Geolocation service failed.' :
    'Error: Your browser doesn\'t support geolocation.');
}
//---------------------------------------------------------------------------------------------------------
//Buscando endereco da geolocalizacao encontrada ----------------------------------------------------------
function recuperaEnderecoGeolocalizado(latitude,longitude)
{
    $('#legenda').show();
    var latlng = latitude + "," +longitude;     
    var url = "http://maps.googleapis.com/maps/api/geocode/json?latlng=" + latlng + "&sensor=true";
    
    var endereco = ''; 
    $.getJSON(url, function (data) {             
        $.ajax({
            dataType: "json",
            url: "script/processaBuscaEstacionamentosProximos.php",
            type: "GET",
            data: {"latitude": latitude,"longitude": longitude},
            success: function(result){               
                carregaEstacionamentosProximos(result);
            }
        });
    });
}
//---------------------------------------------------------------------------------------------------------
//Buscando estacionamentos proximos ao local da busca------------------------------------------------------
function recuperaEstacionamentosProximosEndereco(latitude,longitude)
{
    $.ajax({
        dataType: "json",
        url: "script/processaBuscaEstacionamentosProximos.php",
        type: "GET",
        data: {"latitude": latitude,"longitude": longitude},
        success: function(result){                      
            carregaEstacionamentosProximos(result);
        }
    });
}
//---------------------------------------------------------------------------------------------------------
//Carregando estacionamentos proximos ---------------------------------------------------------------------
function carregaEstacionamentosProximos(valor) 
{
    $.each(valor, function(index, ponto) {
        var icone = 'img/parking.png';
        if(typeof ponto.mais_barato !== 'undefined')
        {
            icone = 'img/parking_custo.png';   
        }
        if(typeof ponto.aberto == 'undefined')
        {
            icone = 'img/parking_fechado.png';   
        }
        var marker = new google.maps.Marker({
            position: new google.maps.LatLng(ponto.latitude, ponto.longitude),
            title: ponto.cod_estacionamento,
            map: map,
            icon: icone
        });
        var lat = marker.getPosition().lat();
        var lng = marker.getPosition().lng();
        var local = lat+','+lng;

        google.maps.event.addListener(marker, 'click', function() {
            $('#informacaoEstacionamento').show();
            buscaInformacoesEstacionamento(ponto.cod_estacionamento,local);
        });
    });
}
//---------------------------------------------------------------------------------------------------------
//Buscando informacao dos estacionamentos------------------------------------------------------------------
function buscaInformacoesEstacionamento(cod_estacionamento,local)
{
   $.ajax({        
        url: "script/carregaInformacoesEstacionamento.php",
        type: "GET",
        data: {"cod_estacionamento": cod_estacionamento},
        success: function(result){               
            $("#conteudoEstacionamento").html(result);
        }
    });
    //recuperando lat long do estacionamento escolhido para tracar rota
    fim = local;
}
//---------------------------------------------------------------------------------------------------------
//Tracando Rota do Ponto ate oe stacionamento escolhido----------------------------------------------------
function tracarRota()
{
    //Mostrando div para informacoes de rota
    $('#trajeto-texto').show();

    directionsDisplay.setMap(map); 

    var request = {
        origin: inicio,
        destination: fim,
        travelMode: google.maps.TravelMode.DRIVING
    };

    directionsService.route(request, function(result, status) {
        if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(result);
        }
    });
    directionsDisplay.setPanel(document.getElementById("trajeto-texto"));
    
}
//---------------------------------------------------------------------------------------------------------
//Buscando por enderecos ----------------------------------------------------------------------------------
function iniciaAutocompletarBusca()
{
    $('#legenda').show();
    var input = document.getElementById('txtEndereco');
    var inputBusca = document.getElementById('bntBusca');
    var options = {
        componentRestrictions: {country: 'br'}
    };
    var autocomplete = new google.maps.places.Autocomplete(input,options);
    var infowindow = new google.maps.InfoWindow();
    var marker = new google.maps.Marker({
        map: map
    });
       
    // Get the full place details when the user selects a place from the
    // list of suggestions.
    google.maps.event.addListener(autocomplete, 'place_changed', function() {
        infowindow.close();
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            return;
        }
        bntBusca.onclick = function() 
        {
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);
            }

            // Set the position of the marker using the place ID and location.
            marker.setPlace(/** @type {!google.maps.Place} */ ({
              placeId: place.place_id,
              location: place.geometry.location
            }));
            var lat = place.geometry.location.lat();
            var lng = place.geometry.location.lng();
            inicio = lat+','+lng;
            
            fechaBuscaPorEndereco();
        
            recuperaEstacionamentosProximosEndereco(lat,lng);
        }         
    }); 
} 